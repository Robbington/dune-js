To run any application here, you need the allegro library compiled, or the dll file
in the main directory. (alleg40.dll)


Grabber -> Reads *.DAT file, extracts data from it