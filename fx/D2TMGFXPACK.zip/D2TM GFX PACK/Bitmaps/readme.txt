Information on this directory:
------------------------------

This directory contains graphics (bitmaps, BMP's) of Dune 2, which are used in my game.
Since i want to provide as much information/data with this package as possible, i also
included these files. I do know they take up a lot of space, but it is really worth
the download. You can really 'see' how the bitmaps are built in order to draw them in
a logical way in the program (as with facing, for units for example).

Do note that the original graphics are by Westwood Studios. Even though i made my 'own'
sidebar out of the original graphics, this still does NOT mean i made the gfx. I just
're-ordered' some stuff. As i said before, my game should be as close to Dune 2.