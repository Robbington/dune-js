note: The bitmaps stored here are used as 'icons' in Dune 2. I have splitted them into
      2 sub-folders. "Structures" and "Units".