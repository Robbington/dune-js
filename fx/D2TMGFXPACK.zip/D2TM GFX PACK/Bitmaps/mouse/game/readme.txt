UI_ files are from Dune Legacy; Although its easy to make them yourself, why do something
that has been done before? I could also rename it , but hence, i dont care; these
files are COPIED from Dune Legacy, and the UI_AlmostValid is 'made' by myself, all i did
was change the color though ;)

NOTE: in the game i have set the pictures to 16 bit (look with grabber in the datafile).