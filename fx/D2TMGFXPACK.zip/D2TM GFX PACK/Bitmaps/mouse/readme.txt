The bmp files located here are the ORIGINAL mouse cursor/bitmaps from Dune 2. The
ones i used are changed ones. I put them in the 'game' directory.