bigone.bmp

containing all the sprites as in the sub-directory; made by Stefan Hendriks

each sprite is 16x16, using the Harkonnen (standard) palette