the pictures in this directory are changed dune 2 pictures! They are NOT the original
pictures stored in the Dune 2 datafile(s).