Nothing here; only purpose this directory has is to show how the others are made:

Day - Month - Year